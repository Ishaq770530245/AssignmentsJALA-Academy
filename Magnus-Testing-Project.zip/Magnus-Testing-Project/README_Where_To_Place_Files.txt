================================================================================
                    MAGNUS TESTING PROJECT - FILE PLACEMENT GUIDE
================================================================================

This document explains WHERE to place each file in your project structure.

================================================================================
RECOMMENDED PROJECT STRUCTURE
================================================================================

Magnus-Testing-Project/
│
├── docs/
│   ├── requirements/
│   │   └── Web_App_Requirement_Doc.pdf          <-- Place original req doc here
│   │
│   ├── test-scenarios/
│   │   └── Magnus_Test_Scenarios.csv            <-- PLACE HERE
│   │
│   ├── test-cases/
│   │   └── Magnus_Test_Cases.csv                <-- PLACE HERE
│   │
│   └── bugs/
│       └── Magnus_Bugs_Jira.txt                 <-- PLACE HERE
│
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/magnus/
│   │           └── pages/                       <-- Page Object Model classes
│   │
│   └── test/
│       └── java/
│           └── com/magnus/automation/
│               └── Magnus_Selenium_Automation.java   <-- PLACE HERE
│
├── drivers/
│   └── chromedriver.exe                         <-- Download ChromeDriver here
│
├── test-output/
│   └── screenshots/                             <-- Auto-captured screenshots
│
├── pom.xml                                      <-- Maven dependencies
└── testng.xml                                   <-- TestNG suite configuration

================================================================================
FILE DESCRIPTIONS & PLACEMENT
================================================================================

1. Magnus_Test_Scenarios.csv
   ----------------------------------------
   WHAT : High-level test scenarios for Magnus application
   WHERE: docs/test-scenarios/
   WHY  : Scenarios are documentation-level artifacts. Keep them in docs/ 
          for easy access by BA, PM, and QA leads.

2. Magnus_Test_Cases.csv
   ----------------------------------------
   WHAT : Detailed test cases with steps, expected results, status
   WHERE: docs/test-cases/
   WHY  : Test cases are the detailed execution plan. Keeping them in docs/
          allows non-technical stakeholders to review them before execution.
   NOTE : You can also import this CSV into TestRail, Zephyr, or Excel.

3. Magnus_Selenium_Automation.java
   ----------------------------------------
   WHAT : Selenium WebDriver automation code (Java + TestNG)
   WHERE: src/test/java/com/magnus/automation/
   WHY  : This is executable test code. It MUST be in src/test/java/ 
          because it contains @Test methods that run during Maven test phase.

   PACKAGE STRUCTURE:
     package com.magnus.automation;

   REQUIRED DEPENDENCIES (pom.xml):
     - selenium-java (4.x)
     - testng (7.x)
     - webdrivermanager (5.x) [optional, for auto driver management]

4. Magnus_Bugs_Jira.txt
   ----------------------------------------
   WHAT : 5 sample bugs logged in JIRA format
   WHERE: docs/bugs/
   WHY  : Bug reports are project documentation. Store them for audit trails 
          and post-mortem analysis.
   NOTE : Copy-paste each bug directly into JIRA "Create Issue" form.

================================================================================
HOW TO RUN THE SELENIUM TESTS
================================================================================

1. Install Prerequisites:
   - Java JDK 11 or higher
   - Maven 3.8+
   - Chrome Browser
   - ChromeDriver (matching your Chrome version)

2. Add dependencies to pom.xml:
   <dependency>
       <groupId>org.seleniumhq.selenium</groupId>
       <artifactId>selenium-java</artifactId>
       <version>4.15.0</version>
   </dependency>
   <dependency>
       <groupId>org.testng</groupId>
       <artifactId>testng</artifactId>
       <version>7.8.0</version>
   </dependency>

3. Place chromedriver.exe in project root or add to PATH.

4. Run tests:
   mvn test

   OR run specific test class:
   mvn test -Dtest=MagnusTestAutomation

================================================================================
INTERVIEW TIPS
================================================================================

When asked "Where do you place test cases?" say:
  "I organize them in a docs/ folder for documentation artifacts, and 
   keep automation scripts in src/test/java/ following Maven standards."

When asked "How do you report bugs?" say:
  "I log them in JIRA with clear reproduction steps, severity/priority, 
   screenshots, and link them to the corresponding test case ID for 
   traceability."

When asked "What is POM?" say:
  "Page Object Model - I separate locators and page actions into dedicated 
   classes under src/main/java/pages/ to make tests maintainable."

================================================================================
