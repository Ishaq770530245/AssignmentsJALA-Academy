package com.magnus.automation;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;
import java.time.Duration;

/**
 * Magnus Application - Selenium Test Automation
 * URL: http://magnus.jalatechnologies.com/
 * Credentials: training@jalaacademy.com / jobprogram
 * 
 * WHERE TO PLACE THIS FILE:
 * src/test/java/com/magnus/automation/MagnusTestAutomation.java
 */
public class MagnusTestAutomation {

    WebDriver driver;
    WebDriverWait wait;

    // Locators
    By usernameField = By.id("UserName");
    By passwordField = By.id("Password");
    By loginButton   = By.id("btnLogin");
    By forgotPasswordLink = By.linkText("Forgot Password");
    By logoutButton  = By.id("btnLogout");

    // Home Page Locators
    By nameSearchField   = By.id("Name");
    By mobileSearchField = By.id("Mobile");
    By searchButton      = By.id("btnSearch");
    By studentGrid       = By.id("tblStudent");

    // Student Creation Locators
    By createTab         = By.linkText("Create");
    By firstNameField    = By.id("FirstName");
    By lastNameField     = By.id("LastName");
    By mobileField       = By.id("Mobile");
    By emailField        = By.id("Email");
    By maleRadio         = By.id("rdbMale");
    By femaleRadio       = By.id("rdbFemale");
    By dobField          = By.id("DOB");
    By qualificationDropdown = By.id("Qualification");
    By chkJava           = By.id("chkJava");
    By chkDotNet         = By.id("chkDotNet");
    By chkPython         = By.id("chkPython");
    By chkDatabase       = By.id("chkDatabase");
    By descriptionField  = By.id("Description");
    By createStudentBtn  = By.id("btnCreate");

    @BeforeClass
    public void setUp() {
        // Set ChromeDriver path if needed
        // System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    // ==================== LOGIN TESTS ====================

    @Test(priority = 1, description = "TC_Login_001: Login with valid credentials")
    public void testLoginWithValidCredentials() {
        driver.get("http://magnus.jalatechnologies.com/");

        driver.findElement(usernameField).sendKeys("training@jalaacademy.com");
        driver.findElement(passwordField).sendKeys("jobprogram");
        driver.findElement(loginButton).click();

        WebElement dashboard = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[contains(text(),'Dashboard')]"))
        );
        Assert.assertTrue(dashboard.isDisplayed(), "Login failed - Dashboard not displayed");
    }

    @Test(priority = 2, description = "TC_Login_002: Login with invalid credentials")
    public void testLoginWithInvalidCredentials() {
        driver.get("http://magnus.jalatechnologies.com/");

        driver.findElement(usernameField).sendKeys("invalid@email.com");
        driver.findElement(passwordField).sendKeys("wrongpassword");
        driver.findElement(loginButton).click();

        WebElement errorMsg = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("alert-danger"))
        );
        Assert.assertTrue(errorMsg.getText().toLowerCase().contains("invalid"), 
            "Error message not displayed for invalid login");
    }

    @Test(priority = 3, description = "TC_Login_003: Verify Forgot Password link")
    public void testForgotPasswordLink() {
        driver.get("http://magnus.jalatechnologies.com/");

        WebElement forgotLink = driver.findElement(forgotPasswordLink);
        Assert.assertTrue(forgotLink.isDisplayed(), "Forgot Password link not visible");
        forgotLink.click();

        // Verify navigation to password reset page
        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.toLowerCase().contains("forgot") || 
                         currentUrl.toLowerCase().contains("reset"),
            "Did not navigate to password reset page");
    }

    // ==================== HOME PAGE TESTS ====================

    @Test(priority = 4, description = "TC_Home_001: Verify student grid is displayed")
    public void testStudentGridDisplayed() {
        login();

        WebElement grid = wait.until(
            ExpectedConditions.visibilityOfElementLocated(studentGrid)
        );
        Assert.assertTrue(grid.isDisplayed(), "Student grid not displayed");
    }

    @Test(priority = 5, description = "TC_Home_002: Search student by Name")
    public void testSearchByName() {
        login();

        driver.findElement(nameSearchField).sendKeys("Ahmed");
        driver.findElement(searchButton).click();

        // Wait for search results
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@id='tblStudent']//tr")));

        WebElement firstResult = driver.findElement(By.xpath("//table[@id='tblStudent']//tr[2]/td[1]"));
        Assert.assertTrue(firstResult.getText().toLowerCase().contains("ahmed"),
            "Search by name did not return correct results");
    }

    @Test(priority = 6, description = "TC_Home_003: Search student by Mobile")
    public void testSearchByMobile() {
        login();

        driver.findElement(mobileSearchField).sendKeys("9876543210");
        driver.findElement(searchButton).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@id='tblStudent']//tr")));

        WebElement mobileCell = driver.findElement(By.xpath("//table[@id='tblStudent']//tr[2]/td[4]"));
        Assert.assertEquals(mobileCell.getText(), "9876543210",
            "Search by mobile did not return correct results");
    }

    @Test(priority = 7, description = "TC_Home_004: Verify grid column headers")
    public void testGridColumnHeaders() {
        login();

        WebElement grid = driver.findElement(studentGrid);
        String gridText = grid.getText();

        Assert.assertTrue(gridText.contains("First Name"), "First Name column missing");
        Assert.assertTrue(gridText.contains("Last Name"), "Last Name column missing");
        Assert.assertTrue(gridText.contains("Skills"), "Skills column missing");
        Assert.assertTrue(gridText.contains("Mobile"), "Mobile column missing");
    }

    // ==================== STUDENT CREATION TESTS ====================

    @Test(priority = 8, description = "TC_Create_001: Create student with valid data")
    public void testCreateStudentValidData() {
        login();
        navigateToStudentCreation();

        fillStudentForm("Ahmed", "Ali", "9876543210", "ahmed@test.com", 
                       "Male", "01/01/1995", "B.Tech", new String[]{"JAVA", "Python"},
                       "Test student description");

        driver.findElement(createStudentBtn).click();

        WebElement successMsg = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("alert-success"))
        );
        Assert.assertTrue(successMsg.isDisplayed(), "Student not created successfully");
    }

    @Test(priority = 9, description = "TC_Create_002: First Name mandatory validation")
    public void testFirstNameMandatory() {
        login();
        navigateToStudentCreation();

        driver.findElement(lastNameField).sendKeys("Ali");
        driver.findElement(mobileField).sendKeys("9876543210");
        driver.findElement(emailField).sendKeys("ahmed@test.com");
        driver.findElement(maleRadio).click();

        driver.findElement(createStudentBtn).click();

        WebElement errorMsg = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("field-validation-error"))
        );
        Assert.assertTrue(errorMsg.getText().toLowerCase().contains("first name"),
            "First Name validation message not shown");
    }

    @Test(priority = 10, description = "TC_Create_003: Last Name mandatory validation")
    public void testLastNameMandatory() {
        login();
        navigateToStudentCreation();

        driver.findElement(firstNameField).sendKeys("Ahmed");
        driver.findElement(mobileField).sendKeys("9876543210");
        driver.findElement(emailField).sendKeys("ahmed@test.com");

        driver.findElement(createStudentBtn).click();

        WebElement errorMsg = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("field-validation-error"))
        );
        Assert.assertTrue(errorMsg.getText().toLowerCase().contains("last name"),
            "Last Name validation message not shown");
    }

    @Test(priority = 11, description = "TC_Create_004: Mobile number format validation")
    public void testMobileFormatValidation() {
        login();
        navigateToStudentCreation();

        driver.findElement(firstNameField).sendKeys("Ahmed");
        driver.findElement(lastNameField).sendKeys("Ali");
        driver.findElement(mobileField).sendKeys("abc123");
        driver.findElement(emailField).sendKeys("ahmed@test.com");

        driver.findElement(createStudentBtn).click();

        WebElement errorMsg = driver.findElement(By.className("field-validation-error"));
        Assert.assertTrue(errorMsg.getText().toLowerCase().contains("mobile") ||
                         errorMsg.getText().toLowerCase().contains("invalid"),
            "Mobile validation message not shown");
    }

    @Test(priority = 12, description = "TC_Create_005: Email format validation")
    public void testEmailFormatValidation() {
        login();
        navigateToStudentCreation();

        driver.findElement(firstNameField).sendKeys("Ahmed");
        driver.findElement(lastNameField).sendKeys("Ali");
        driver.findElement(mobileField).sendKeys("9876543210");
        driver.findElement(emailField).sendKeys("invalid-email");

        driver.findElement(createStudentBtn).click();

        WebElement errorMsg = driver.findElement(By.className("field-validation-error"));
        Assert.assertTrue(errorMsg.getText().toLowerCase().contains("email") ||
                         errorMsg.getText().toLowerCase().contains("invalid"),
            "Email validation message not shown");
    }

    @Test(priority = 13, description = "TC_Create_006: Gender radio button selection")
    public void testGenderSelection() {
        login();
        navigateToStudentCreation();

        driver.findElement(maleRadio).click();
        Assert.assertTrue(driver.findElement(maleRadio).isSelected(), "Male radio not selected");

        driver.findElement(femaleRadio).click();
        Assert.assertTrue(driver.findElement(femaleRadio).isSelected(), "Female radio not selected");
    }

    @Test(priority = 14, description = "TC_Create_007: DOB date picker")
    public void testDatePicker() {
        login();
        navigateToStudentCreation();

        WebElement dob = driver.findElement(dobField);
        dob.sendKeys("01/01/1995");
        Assert.assertEquals(dob.getAttribute("value"), "01/01/1995", "DOB not set correctly");
    }

    @Test(priority = 15, description = "TC_Create_008: Qualification dropdown")
    public void testQualificationDropdown() {
        login();
        navigateToStudentCreation();

        Select dropdown = new Select(driver.findElement(qualificationDropdown));
        dropdown.selectByVisibleText("B.Tech");

        Assert.assertEquals(dropdown.getFirstSelectedOption().getText(), "B.Tech",
            "Qualification not selected correctly");
    }

    @Test(priority = 16, description = "TC_Create_009: Skills checkboxes")
    public void testSkillsCheckboxes() {
        login();
        navigateToStudentCreation();

        driver.findElement(chkJava).click();
        driver.findElement(chkPython).click();

        Assert.assertTrue(driver.findElement(chkJava).isSelected(), "JAVA checkbox not selected");
        Assert.assertTrue(driver.findElement(chkPython).isSelected(), "Python checkbox not selected");
    }

    // ==================== EDIT & DELETE TESTS ====================

    @Test(priority = 17, description = "TC_Edit_001: Edit existing student")
    public void testEditStudent() {
        login();

        // Click edit on first student
        WebElement editBtn = wait.until(
            ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='tblStudent']//tr[2]//button[contains(@class,'btn-edit')]"))
        );
        editBtn.click();

        // Modify last name
        WebElement editLastName = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.id("EditLastName"))
        );
        editLastName.clear();
        editLastName.sendKeys("UpdatedName");

        driver.findElement(By.id("btnUpdate")).click();

        // Verify navigation back to home
        WebElement grid = wait.until(
            ExpectedConditions.visibilityOfElementLocated(studentGrid)
        );
        Assert.assertTrue(grid.isDisplayed(), "Not navigated back to Home after edit");
    }

    @Test(priority = 18, description = "TC_Delete_001: Delete student with confirmation")
    public void testDeleteStudent() {
        login();

        // Click delete on first student
        WebElement deleteBtn = wait.until(
            ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='tblStudent']//tr[2]//button[contains(@class,'btn-delete')]"))
        );
        deleteBtn.click();

        // Handle confirmation popup (Alert or Modal)
        try {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            Assert.assertTrue(alertText.toLowerCase().contains("delete"),
                "Delete confirmation message incorrect");
            alert.accept();
        } catch (NoAlertPresentException e) {
            // Handle modal popup if not browser alert
            WebElement confirmBtn = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Yes')]"))
            );
            confirmBtn.click();
        }

        WebElement successMsg = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("alert-success"))
        );
        Assert.assertTrue(successMsg.isDisplayed(), "Student not deleted successfully");
    }

    // ==================== PAGINATION & LOGOUT ====================

    @Test(priority = 19, description = "TC_Pagination_001: Verify pagination 50 records")
    public void testPagination() {
        login();

        Select pageSize = new Select(driver.findElement(By.id("pageSize")));
        pageSize.selectByVisibleText("50");

        // Wait for grid to refresh
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@id='tblStudent']//tr")));

        int rowCount = driver.findElements(By.xpath("//table[@id='tblStudent']//tr")).size() - 1; // minus header
        Assert.assertTrue(rowCount <= 50, "Pagination showing more than 50 records");
    }

    @Test(priority = 20, description = "TC_Logout_001: Verify logout functionality")
    public void testLogout() {
        login();

        driver.findElement(logoutButton).click();

        WebElement loginPage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(loginButton)
        );
        Assert.assertTrue(loginPage.isDisplayed(), "Logout failed - Login page not displayed");
    }

    // ==================== HELPER METHODS ====================

    private void login() {
        driver.get("http://magnus.jalatechnologies.com/");
        driver.findElement(usernameField).sendKeys("training@jalaacademy.com");
        driver.findElement(passwordField).sendKeys("jobprogram");
        driver.findElement(loginButton).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(studentGrid));
    }

    private void navigateToStudentCreation() {
        driver.findElement(By.linkText("Student")).click();
        driver.findElement(createTab).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField));
    }

    private void fillStudentForm(String firstName, String lastName, String mobile, 
                                 String email, String gender, String dob, String qualification,
                                 String[] skills, String description) {
        driver.findElement(firstNameField).sendKeys(firstName);
        driver.findElement(lastNameField).sendKeys(lastName);
        driver.findElement(mobileField).sendKeys(mobile);
        driver.findElement(emailField).sendKeys(email);

        if (gender.equalsIgnoreCase("Male")) {
            driver.findElement(maleRadio).click();
        } else {
            driver.findElement(femaleRadio).click();
        }

        driver.findElement(dobField).sendKeys(dob);

        Select qualDropdown = new Select(driver.findElement(qualificationDropdown));
        qualDropdown.selectByVisibleText(qualification);

        for (String skill : skills) {
            if (skill.equalsIgnoreCase("JAVA")) driver.findElement(chkJava).click();
            if (skill.equalsIgnoreCase(".Net")) driver.findElement(chkDotNet).click();
            if (skill.equalsIgnoreCase("Python")) driver.findElement(chkPython).click();
            if (skill.equalsIgnoreCase("Database")) driver.findElement(chkDatabase).click();
        }

        driver.findElement(descriptionField).sendKeys(description);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
